import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-16 bg-brand-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12">
          
          <div>
            <h2 className="text-3xl font-extrabold sm:text-4xl mb-6">Get In Touch</h2>
            <p className="text-brand-100 text-lg mb-8">
              Interested in our Overdraft Facilities or Personal Loan offerings? 
              Our team is here to guide you through the process and answer any questions.
            </p>
            
            <div className="space-y-6 mb-8">
              <div className="flex items-start">
                <Phone className="h-6 w-6 text-brand-400 mt-1" />
                <div className="ml-4">
                  <p className="text-lg font-medium">Contact Us</p>
                  <p className="text-brand-100">+91 123 456 7890</p>
                </div>
              </div>
              <div className="flex items-start">
                <Mail className="h-6 w-6 text-brand-400 mt-1" />
                <div className="ml-4">
                  <p className="text-lg font-medium">Email</p>
                  <p className="text-brand-100">info@ank.finance</p>
                </div>
              </div>
              <div className="flex items-start">
                <MapPin className="h-6 w-6 text-brand-400 mt-1" />
                <div className="ml-4">
                  <p className="text-lg font-medium">Office</p>
                  <p className="text-brand-100">Indore, Madhya Pradesh</p>
                </div>
              </div>
            </div>

            {/* Google Map Embed */}
            <div className="w-full h-64 rounded-xl overflow-hidden shadow-lg border border-brand-700 bg-brand-800">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d235850.6628620857!2d75.72051680212048!3d22.7242031754876!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3962fcad1b410ddb%3A0x96ec4da433678078!2sIndore%2C%20Madhya%20Pradesh!5e0!3m2!1sen!2sin!4v1710330000000!5m2!1sen!2sin" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen={true} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Office Location Map"
              ></iframe>
            </div>
          </div>

          <div className="bg-white rounded-lg p-8 text-slate-900 shadow-xl">
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-slate-700">Full Name</label>
                <input type="text" id="name" className="mt-1 block w-full border border-slate-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-brand-500 focus:border-brand-500" placeholder="John Doe" />
              </div>
              <div>
                <label htmlFor="company" className="block text-sm font-medium text-slate-700">Company Name</label>
                <input type="text" id="company" className="mt-1 block w-full border border-slate-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-brand-500 focus:border-brand-500" placeholder="Your Employer" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                    <label htmlFor="email" className="block text-sm font-medium text-slate-700">Email</label>
                    <input type="email" id="email" className="mt-1 block w-full border border-slate-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-brand-500 focus:border-brand-500" placeholder="john@example.com" />
                </div>
                <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-slate-700">Phone</label>
                    <input type="tel" id="phone" className="mt-1 block w-full border border-slate-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-brand-500 focus:border-brand-500" placeholder="+91..." />
                </div>
              </div>
              <div>
                <label htmlFor="product" className="block text-sm font-medium text-slate-700">Interested Product</label>
                <select id="product" className="mt-1 block w-full border border-slate-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-brand-500 focus:border-brand-500">
                  <option>Overdraft Facility (Flexi)</option>
                  <option>Personal Loan</option>
                  <option>Business Loan</option>
                </select>
              </div>
              <div>
                <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-brand-600 hover:bg-brand-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500">
                  Request Call Back
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;